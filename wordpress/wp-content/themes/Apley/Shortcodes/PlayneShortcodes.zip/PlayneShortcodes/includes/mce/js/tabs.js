jQuery(function($){
	$(document).ready(function(){$( ".tabs" ).tabs();});
});